from tkinter import *

window = Tk()
window.geometry('1000x1000')

e = Entry(width=75, borderwidth=15)
e.place(x=0, y=0)

def click(num):
    result = e.get()
    e.delete(0, END)
    e.insert(0, str(result) + str(num))

# Numbers
b7 = Button(window, text='7', width=15, command=lambda: click(7))
b7.place(x=10, y=60)
b8 = Button(window, text='8', width=15, command=lambda: click(8))
b8.place(x=90, y=60)
b9 = Button(window, text='9', width=15, command=lambda: click(9))
b9.place(x=170, y=60)

b4 = Button(window, text='4', width=15, command=lambda: click(4))
b4.place(x=10, y=130)
b5 = Button(window, text='5', width=15, command=lambda: click(5))
b5.place(x=90, y=130)
b6 = Button(window, text='6', width=15, command=lambda: click(6))
b6.place(x=170, y=130)

b1 = Button(window, text='1', width=15, command=lambda: click(1))
b1.place(x=10, y=200)
b2 = Button(window, text='2', width=15, command=lambda: click(2))
b2.place(x=90, y=200)
b3 = Button(window, text='3', width=15, command=lambda: click(3))
b3.place(x=170, y=200)

b0 = Button(window, text='0', width=15, command=lambda: click(0))  # Added command here
b0.place(x=10, y=270)

# Operators
def add():
    n1 = e.get()
    global math
    math = "addition"
    global i
    i = int(n1)
    e.delete(0, END)

b_add = Button(window, text='+', width=15, command=add)
b_add.place(x=250, y=60)

def sub():
    n1 = e.get()
    global math
    math = "Subtration"
    global i
    i = int(n1)
    e.delete(0, END)

b_sub = Button(window, text='-', width=15, command=sub)
b_sub.place(x=250, y=130)

def mul():
    n1 = e.get()
    global math
    math = "Multiplication"
    global i
    i = int(n1)
    e.delete(0, END)

b_mul = Button(window, text='*', width=15, command=mul)
b_mul.place(x=250, y=200)

def div():
    n1 = e.get()
    global math
    math = "Division"
    global i
    i = int(n1)
    e.delete(0, END)

b_div = Button(window, text='/', width=15, command=div)
b_div.place(x=250, y=270)

def equal():
    n2 = e.get()
    e.delete(0, END)
    if math == "addition":
        e.insert(0, i + int(n2))
    elif math == "Subtration":
        e.insert(0, i - int(n2))
    elif math == "Multiplication":
        e.insert(0, i * int(n2))
    elif math == "Division":
        e.insert(0, i / int(n2))

b_eq = Button(window, text='=', width=15, command=equal) 
b_eq.place(x=90, y=340)

def clear():
    e.delete(0, END)

b_clr = Button(window, text='CLR', width=15, command=clear)  
b_clr.place(x=170, y=340)

mainloop()
